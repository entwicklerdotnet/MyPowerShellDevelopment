<!--
If you are reporting a new issue, please first search for a matching issue in
this repository.

-->


**Output of `$PSVersionTable` (from a powershell process):**

```
(paste your output here)
```

**Output of `ipmo Docker; (module Docker).Version.ToString()` (from a powershell process):**

```
(paste your output here)
```

**Steps to reproduce the issue:**
1.
2.
3.


**What actually happened?:**


**What did you expect to happen?:**


**Additional information:**